from django.contrib import admin
from .models import Borrow

admin.site.register(Borrow)
